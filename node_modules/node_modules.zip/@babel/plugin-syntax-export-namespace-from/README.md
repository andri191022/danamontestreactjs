# @babel/plugin-syntax-export-namespace-from

> Allow parsing of export namespace from

See our website [@babel/plugin-syntax-export-namespace-from](https://babeljs.io/docs/en/next/babel-plugin-syntax-export-namespace-from.html) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-syntax-export-namespace-from
```

or using yarn:

```sh
yarn add @babel/plugin-syntax-export-namespace-from --dev
```
