// TODO: Remove in Babel 8
// https://github.com/vuejs/vue-cli/issues/3671

module.exports = require("./corejs2-built-ins.json");
