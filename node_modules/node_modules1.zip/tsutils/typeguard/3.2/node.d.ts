export * from '../3.0/node';
import * as ts from 'typescript';
export declare function isBigIntLiteral(node: ts.Node): node is ts.BigIntLiteral;
