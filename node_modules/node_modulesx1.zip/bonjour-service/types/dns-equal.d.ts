declare module 'dns-equal' {
    function equal(a: string, b: string): boolean
    export = equal
}