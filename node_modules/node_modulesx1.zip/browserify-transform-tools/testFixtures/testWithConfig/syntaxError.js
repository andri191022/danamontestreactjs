x = require("foo");
y = {foo: "bar";