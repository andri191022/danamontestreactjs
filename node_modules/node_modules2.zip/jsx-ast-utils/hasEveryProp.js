module.exports = require('./lib').hasEveryProp; // eslint-disable-line import/no-unresolved
